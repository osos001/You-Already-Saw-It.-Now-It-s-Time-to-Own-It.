import { useState, useEffect, useRef } from 'react'
import './App.css'

function App() {
  const [scrollY, setScrollY] = useState(0)
  const [cursorPos, setCursorPos] = useState({ x: 0, y: 0 })
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [activeSection, setActiveSection] = useState('hero')
  const [visibleSections, setVisibleSections] = useState<Set<string>>(new Set())

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    const handleMouse = (e: MouseEvent) => setCursorPos({ x: e.clientX, y: e.clientY })

    window.addEventListener('scroll', handleScroll)
    window.addEventListener('mousemove', handleMouse)

    return () => {
      window.removeEventListener('scroll', handleScroll)
      window.removeEventListener('mousemove', handleMouse)
    }
  }, [])

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id)
            setVisibleSections((prev) => new Set(prev).add(entry.target.id))
          }
        })
      },
      { threshold: 0.2 }
    )

    document.querySelectorAll('section[id]').forEach((section) => {
      observer.observe(section)
    })

    return () => observer.disconnect()
  }, [])

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
    setIsMenuOpen(false)
  }

  const isVisible = (id: string) => visibleSections.has(id)

  return (
    <div className="portfolio">
      {/* Custom Cursor */}
      <div
        className="cursor"
        style={{ left: cursorPos.x, top: cursorPos.y }}
      />
      <div
        className="cursor-dot"
        style={{ left: cursorPos.x, top: cursorPos.y }}
      />

      {/* Grain Overlay */}
      <div className="grain" />

      {/* Navigation */}
      <nav className={`nav ${scrollY > 50 ? 'nav-scrolled' : ''}`}>
        <div className="nav-content">
          <div className="logo">
            <span className="logo-text">Alex Chen</span>
          </div>
          <div className={`nav-links ${isMenuOpen ? 'open' : ''}`}>
            <button onClick={() => scrollToSection('hero')} className={activeSection === 'hero' ? 'active' : ''}>Home</button>
            <button onClick={() => scrollToSection('about')} className={activeSection === 'about' ? 'active' : ''}>About</button>
            <button onClick={() => scrollToSection('services')} className={activeSection === 'services' ? 'active' : ''}>Services</button>
            <button onClick={() => scrollToSection('work')} className={activeSection === 'work' ? 'active' : ''}>Work</button>
            <button onClick={() => scrollToSection('testimonials')} className={activeSection === 'testimonials' ? 'active' : ''}>Testimonials</button>
            <button onClick={() => scrollToSection('contact')} className="nav-cta">Let's Talk</button>
          </div>
          <button className="menu-toggle" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            <span></span>
            <span></span>
            <span></span>
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="hero" className="hero">
        <div className="hero-bg">
          <div className="hero-gradient" style={{ transform: `translateY(${scrollY * 0.3}px)` }} />
          <div className="hero-orb orb-1" style={{ transform: `translate(${scrollY * 0.1}px, ${scrollY * 0.05}px)` }} />
          <div className="hero-orb orb-2" style={{ transform: `translate(${-scrollY * 0.1}px, ${scrollY * 0.08}px)` }} />
        </div>
        <div className={`hero-content ${isVisible('hero') ? 'visible' : ''}`}>
          <div className="hero-badge">
            <span className="badge-dot" />
            Available for Projects
          </div>
          <h1 className="hero-title">
            I Design <span className="gradient-text">Digital Experiences</span> That Convert
          </h1>
          <p className="hero-subtitle">
            Senior UI/UX Designer helping ambitious brands create websites that don't just look beautiful — they generate real business results.
          </p>
          <div className="hero-stats">
            <div className="stat">
              <span className="stat-number">150+</span>
              <span className="stat-label">Projects Delivered</span>
            </div>
            <div className="stat-divider" />
            <div className="stat">
              <span className="stat-number">8+</span>
              <span className="stat-label">Years Experience</span>
            </div>
            <div className="stat-divider" />
            <div className="stat">
              <span className="stat-number">$2.4M</span>
              <span className="stat-label">Revenue Generated</span>
            </div>
          </div>
          <div className="hero-cta">
            <button className="btn-primary" onClick={() => scrollToSection('contact')}>
              Start Your Project
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M5 12h14M12 5l7 7-7 7"/>
              </svg>
            </button>
            <button className="btn-secondary" onClick={() => scrollToSection('work')}>
              View My Work
            </button>
          </div>
          <div className="hero-scroll">
            <span>Scroll to explore</span>
            <div className="scroll-line" />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="about">
        <div className={`section-content ${isVisible('about') ? 'visible' : ''}`}>
          <div className="about-grid">
            <div className="about-image">
              <div className="image-wrapper">
                <div className="image-placeholder">
                  <span>AC</span>
                </div>
                <div className="image-border" />
              </div>
              <div className="about-decoration">
                <div className="deco-circle" />
                <div className="deco-line" />
              </div>
            </div>
            <div className="about-text">
              <span className="section-label">About Me</span>
              <h2>Turning Vision Into <span className="gradient-text">Visually Stunning</span> Reality</h2>
              <p>
                I'm Alex Chen, a UI/UX designer based in San Francisco with a passion for creating digital products that make people say "wow."
              </p>
              <p>
                My approach combines strategic thinking with pixel-perfect execution. I don't just make things look good — I design with conversion in mind, ensuring every element serves a purpose.
              </p>
              <div className="about-highlights">
                <div className="highlight">
                  <div className="highlight-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                    </svg>
                  </div>
                  <div>
                    <h4>Brand Strategy</h4>
                    <p>Deep research into your market and competitors</p>
                  </div>
                </div>
                <div className="highlight">
                  <div className="highlight-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                      <circle cx="8.5" cy="8.5" r="1.5"/>
                      <path d="M21 15l-5-5L5 21"/>
                    </svg>
                  </div>
                  <div>
                    <h4>Pixel-Perfect Design</h4>
                    <p>Meticulous attention to every detail</p>
                  </div>
                </div>
                <div className="highlight">
                  <div className="highlight-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
                    </svg>
                  </div>
                  <div>
                    <h4>Performance First</h4>
                    <p>Lightning-fast, SEO-optimized websites</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="services">
        <div className={`section-content ${isVisible('services') ? 'visible' : ''}`}>
          <div className="section-header">
            <span className="section-label">Services</span>
            <h2>What I <span className="gradient-text">Bring to the Table</span></h2>
            <p>Comprehensive design solutions tailored to your unique business needs</p>
          </div>
          <div className="services-grid">
            <div className="service-card">
              <div className="service-icon">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
                  <line x1="8" y1="21" x2="16" y2="21"/>
                  <line x1="12" y1="17" x2="12" y2="21"/>
                </svg>
              </div>
              <h3>Landing Page Design</h3>
              <p>High-converting landing pages designed to turn visitors into paying customers. Every pixel optimized for results.</p>
              <ul className="service-features">
                <li>A/B Testing Setup</li>
                <li>Conversion Optimization</li>
                <li>Mobile-First Approach</li>
              </ul>
              <div className="service-price">
                <span>Starting at</span>
                <strong>$1,500</strong>
              </div>
            </div>
            <div className="service-card featured">
              <div className="featured-badge">Most Popular</div>
              <div className="service-icon">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M12 2L2 7l10 5 10-5-10-5z"/>
                  <path d="M2 17l10 5 10-5"/>
                  <path d="M2 12l10 5 10-5"/>
                </svg>
              </div>
              <h3>Full Website Design</h3>
              <p>Complete website packages including branding, design, and development. Everything you need to launch.</p>
              <ul className="service-features">
                <li>Up to 10 Pages</li>
                <li>CMS Integration</li>
                <li>SEO Optimization</li>
                <li>Analytics Setup</li>
              </ul>
              <div className="service-price">
                <span>Starting at</span>
                <strong>$4,500</strong>
              </div>
            </div>
            <div className="service-card">
              <div className="service-icon">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
                  <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
                  <line x1="12" y1="22.08" x2="12" y2="12"/>
                </svg>
              </div>
              <h3>UI/UX Design</h3>
              <p>User interface and experience design for web and mobile applications. Intuitive, accessible, and beautiful.</p>
              <ul className="service-features">
                <li>User Research</li>
                <li>Wireframing</li>
                <li>Prototyping</li>
              </ul>
              <div className="service-price">
                <span>Starting at</span>
                <strong>$2,500</strong>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section id="work" className="process">
        <div className={`section-content ${isVisible('work') ? 'visible' : ''}`}>
          <div className="section-header">
            <span className="section-label">My Process</span>
            <h2>How We <span className="gradient-text">Work Together</span></h2>
            <p>A proven methodology that delivers results, every single time</p>
          </div>
          <div className="process-timeline">
            <div className="process-step">
              <div className="step-number">01</div>
              <div className="step-content">
                <h3>Discovery</h3>
                <p>We dive deep into your business, goals, and target audience. I analyze your competition and identify opportunities.</p>
              </div>
              <div className="step-line" />
            </div>
            <div className="process-step">
              <div className="step-number">02</div>
              <div className="step-content">
                <h3>Strategy</h3>
                <p>I create a comprehensive design strategy with wireframes and user flows. We align on direction before diving into design.</p>
              </div>
              <div className="step-line" />
            </div>
            <div className="process-step">
              <div className="step-number">03</div>
              <div className="step-content">
                <h3>Design</h3>
                <p>High-fidelity designs come to life. I create detailed mockups with every state and interaction mapped out.</p>
              </div>
              <div className="step-line" />
            </div>
            <div className="process-step">
              <div className="step-number">04</div>
              <div className="step-content">
                <h3>Launch</h3>
                <p>Final reviews, revisions, and deployment. I ensure everything is pixel-perfect and ready to convert.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Work With Me */}
      <section id="why" className="why">
        <div className={`section-content ${isVisible('why') ? 'visible' : ''}`}>
          <div className="why-grid">
            <div className="why-text">
              <span className="section-label">Why Choose Me</span>
              <h2>Not Just Another <span className="gradient-text">Freelancer</span></h2>
              <p className="why-intro">
                I don't just design websites. I design business tools that generate revenue. Here's what sets me apart:
              </p>
              <div className="why-features">
                <div className="why-feature">
                  <span className="feature-check">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                      <polyline points="20 6 9 17 4 12"/>
                    </svg>
                  </span>
                  <div>
                    <h4>Results-Driven Approach</h4>
                    <p>Every design decision backed by conversion data and user psychology</p>
                  </div>
                </div>
                <div className="why-feature">
                  <span className="feature-check">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                      <polyline points="20 6 9 17 4 12"/>
                    </svg>
                  </span>
                  <div>
                    <h4>Direct Communication</h4>
                    <p>No account managers. You work directly with me throughout the project</p>
                  </div>
                </div>
                <div className="why-feature">
                  <span className="feature-check">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                      <polyline points="20 6 9 17 4 12"/>
                    </svg>
                  </span>
                  <div>
                    <h4>Fast Turnaround</h4>
                    <p>Most projects delivered within 2-3 weeks without sacrificing quality</p>
                  </div>
                </div>
                <div className="why-feature">
                  <span className="feature-check">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                      <polyline points="20 6 9 17 4 12"/>
                    </svg>
                  </span>
                  <div>
                    <h4>Post-Launch Support</h4>
                    <p>30 days of free support after launch to ensure everything runs smoothly</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="why-stats">
              <div className="big-stat">
                <span className="big-number">98%</span>
                <span className="big-label">Client Satisfaction Rate</span>
              </div>
              <div className="stat-row">
                <div className="mini-stat">
                  <span className="mini-number">3x</span>
                  <span className="mini-label">Average ROI Increase</span>
                </div>
                <div className="mini-stat">
                  <span className="mini-number">24h</span>
                  <span className="mini-label">Response Time</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="testimonials">
        <div className={`section-content ${isVisible('testimonials') ? 'visible' : ''}`}>
          <div className="section-header">
            <span className="section-label">Testimonials</span>
            <h2>What My <span className="gradient-text">Clients Say</span></h2>
            <p>Don't take my word for it — hear from the businesses I've helped grow</p>
          </div>
          <div className="testimonials-grid">
            <div className="testimonial-card">
              <div className="testimonial-stars">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                  </svg>
                ))}
              </div>
              <p className="testimonial-text">
                "Alex completely transformed our online presence. Our conversion rate jumped 340% in the first month after launching the new site. The attention to detail and strategic thinking was exceptional."
              </p>
              <div className="testimonial-author">
                <div className="author-avatar">JM</div>
                <div>
                  <strong>James Morrison</strong>
                  <span>CEO, TechFlow Solutions</span>
                </div>
              </div>
            </div>
            <div className="testimonial-card featured-testimonial">
              <div className="testimonial-stars">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                  </svg>
                ))}
              </div>
              <p className="testimonial-text">
                "Working with Alex was a game-changer. The portfolio they created for me attracted my dream clients within weeks. I went from struggling to find work to being fully booked for months. Worth every penny."
              </p>
              <div className="testimonial-author">
                <div className="author-avatar">SK</div>
                <div>
                  <strong>Sarah Kim</strong>
                  <span>Creative Director, Independent</span>
                </div>
              </div>
            </div>
            <div className="testimonial-card">
              <div className="testimonial-stars">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                  </svg>
                ))}
              </div>
              <p className="testimonial-text">
                "The strategic approach Alex brings is unmatched. They didn't just design a website — they designed a business tool that now generates consistent leads every single week."
              </p>
              <div className="testimonial-author">
                <div className="author-avatar">MR</div>
                <div>
                  <strong>Michael Roberts</strong>
                  <span>Founder, GrowthLabs</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="faq">
        <div className={`section-content ${isVisible('faq') ? 'visible' : ''}`}>
          <div className="faq-grid">
            <div className="faq-header">
              <span className="section-label">FAQ</span>
              <h2>Got <span className="gradient-text">Questions?</span></h2>
              <p>Here are answers to the most common questions I receive</p>
            </div>
            <div className="faq-list">
              <div className="faq-item">
                <h4>How long does a typical project take?</h4>
                <p>Most landing pages are completed in 1-2 weeks, while full websites typically take 3-4 weeks. Complex projects may take longer, but I'll give you a clear timeline upfront.</p>
              </div>
              <div className="faq-item">
                <h4>What's included in the package?</h4>
                <p>Everything you need: design files, responsive development, basic SEO setup, analytics integration, and 30 days of post-launch support. No hidden fees.</p>
              </div>
              <div className="faq-item">
                <h4>Do you work with clients remotely?</h4>
                <p>Absolutely! I've worked with clients across the globe. We use video calls, shared collaboration tools, and async communication to make the process seamless.</p>
              </div>
              <div className="faq-item">
                <h4>What if I need revisions?</h4>
                <p>All packages include up to 2 rounds of revisions. I work closely with you during the design phase to ensure we're aligned before finalizing.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="contact" className="cta-section">
        <div className={`cta-content ${isVisible('contact') ? 'visible' : ''}`}>
          <div className="cta-glow" />
          <div className="cta-badge">
            <span className="badge-dot" />
            Limited Spots Available
          </div>
          <h2>Ready to <span className="gradient-text">Transform</span> Your Online Presence?</h2>
          <p>
            Let's create something extraordinary together. Book a free strategy call and let's discuss how I can help you achieve your business goals.
          </p>
          <div className="cta-buttons">
            <a href="https://tarekster34.gumroad.com/l/qmggnd" target="_blank" rel="noopener noreferrer" className="btn-primary large">
              Get Your Portfolio — 50% Off
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M5 12h14M12 5l7 7-7 7"/>
              </svg>
            </a>
          </div>
          <p className="cta-guarantee">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
              <polyline points="9 12 11 14 15 10"/>
            </svg>
            30-day money-back guarantee. No questions asked.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="footer-content">
          <div className="footer-main">
            <div className="footer-brand">
              <span className="logo-text">Alex Chen</span>
              <p>Creating digital experiences that convert visitors into loyal customers.</p>
            </div>
            <div className="footer-links">
              <div className="footer-col">
                <h5>Quick Links</h5>
                <a href="#about">About</a>
                <a href="#services">Services</a>
                <a href="#work">Work</a>
                <a href="#contact">Contact</a>
              </div>
              <div className="footer-col">
                <h5>Services</h5>
                <a href="#services">Landing Pages</a>
                <a href="#services">Website Design</a>
                <a href="#services">UI/UX Design</a>
                <a href="#services">Branding</a>
              </div>
              <div className="footer-col">
                <h5>Connect</h5>
                <a href="#">Twitter</a>
                <a href="#">LinkedIn</a>
                <a href="#">Dribbble</a>
                <a href="#">Instagram</a>
              </div>
            </div>
          </div>
          <div className="footer-bottom">
            <p>© 2025 Alex Chen Design. All rights reserved.</p>
            <div className="footer-badges">
              <span className="badge">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                </svg>
                SSL Secured
              </span>
              <span className="badge">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                  <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                </svg>
                Payments Protected
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App
